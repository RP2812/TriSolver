/*
Author:-  Rudra Patel
Date:- 30 jan 2023
Purpose:- To find Triangle Types angels,sides and Side types.(Trigonometry.)
file: - Rudra_TriSolver.c

*/

//header
#include <stdio.h>          //For Standard Input
#define _USE_MATH_DEFINES   //For Math functions
#include <math.h>           //Fr math libraries and functions
#include<stdint.h>          // for standard Integers
#include<stdlib.h>          //For standard libraries
#include<string.h>          //For strings and their functions
#define total_deg (180.0)   // predefine total_deg as 180
typedef double Tri_input;   //define double as Tri_input
typedef char Tri_char;      //define char as Tri_input



/*
fn:- angleType with Tri_char pointor
purpose :- to find type of Angle of Triangle
param:- a,b,c import from triangle
return :- Angletype of triangle

*/
Tri_char* angleType(Tri_input a, Tri_input b, Tri_input c)
{
	Tri_input longest;
	longest = c;
	if (longest < a) {
		c = longest;
		longest = a;
		a = c;
	}
	if (longest < b) {
		c = longest;
		longest = b;
		b = c;
	}
	if (a * a + b * b == longest * longest) {
		return " right";
	}
	else if (a * a + b * b > longest * longest) {
		return "acute";
	}
	else {
		return " obtuse";
	}
}




/*
fn:- SideType with Tri_char pointor
purpose :- to find type of SideType of Triangle
param:- a,b,c,Alpha,Beta,Gamma import from triangle
return :- Sidetype of triangle

*/
Tri_char* SideType(Tri_input a, Tri_input b, Tri_input c, Tri_input Alpha, Tri_input Beta, Tri_input Gamma) {
	if (a == b && b == c)
	{
		return "equilateral";
	}
	else if (a == b || a == c || b == c)
	{
		return "isosceles";
	}
	else
	{
		return "scalene";
	}
}




/*
fn:- printInfo with void type
purpose :- to Print Details of Triangle
param:- A,B,C,type,Alpha,Beta,Gamma,permeter,Area ,Sidetype,Angletype import from triangle
return :- N/A

*/
void printInfo(Tri_char* type, Tri_input a, Tri_input b, Tri_input c, Tri_input alpha, Tri_input beta, Tri_input gamma, Tri_input perimeter, Tri_input area, Tri_char* sidetype, Tri_char* angletype)
{
	printf("\nFormat: %s\n", type);
	printf("a = %7.3f      alpha = %8.3f\n", a, alpha);
	printf("b = %7.3f      beta  = %8.3f\n", b, beta);
	printf("c = %7.3f      gamma = %8.3f\n", c, gamma);
	printf("Perimeter = %7.3f\n", perimeter);
	printf("Area      = %7.3f\n", area);
	printf("Type      = %s,%s\n", sidetype, angletype);
}





/*
fn:- Perimeter
purpose :- to find Perimeter
param:- a,b,c import from triangle
return :- Perimeter of triangle

*/
//Perimeter Of Triangle
Tri_input Perimeter(Tri_input a, Tri_input b, Tri_input c)
{
	Tri_input perimeter = a + b + c;
	return perimeter;
}



/*
fn:- semiPerimeter
purpose :- to find semiPerimeter
param:- Perimeter import from triangle
return :- semiPerimeter of triangle

*/
//semi perimeter
Tri_input semiPerimeter(Tri_input perimeter)
{
	Tri_input semiPerimeter = (perimeter) / 2;
	return semiPerimeter;
}




/*
fn:- Area
purpose :- to find Area
param:- a,b,c,semiPerimeter import from triangle
return :- Area of triangle

*/
//Area
Tri_input Area(Tri_input a, Tri_input b, Tri_input c, Tri_input semiPerimeter)
{
	Tri_input area = sqrt(semiPerimeter * ((semiPerimeter - a) * (semiPerimeter - b) * (semiPerimeter - c)));
	return area;
}




/*
fn:- SSA with void type
purpose :- to find SSA
param:- b,c,beta import from triangle
return :- N/A

*/

//SSA
void ssa(Tri_input b, Tri_input c, Tri_input beta)
{
	Tri_char* sidetype;
	Tri_char* angletype;
	Tri_input Gamma1, alpha1, a1, Gamma2, perimeter, semiperimeter, area, alpha2, a2;

	//Degree to Radian
	Tri_input bRadian = (beta * M_PI) / 180;
	Gamma1 = asin(((c * sin(bRadian)) / b));
	Gamma1 = (Gamma1 * 180) / M_PI;





	//other answer
	Gamma2 = total_deg - Gamma1;

	if ((Gamma2 + beta) > total_deg)
	{
		alpha1 = total_deg - (beta + Gamma1);
		//Degree to Radian
		Tri_input a1Radian = (alpha1 * M_PI) / 180;
		a1 = ((sin(a1Radian) * b) / sin(bRadian));


		if ((a1 + b < c && b + c < a1 && a1 + c < b) || (a1 == 0 || b == 0 || c == 0) || alpha1 + beta + Gamma1 != total_deg)
		{
			printf("Impossible triangle");
		}
		else {
			perimeter = Perimeter(a1, b, c);
			semiperimeter = semiPerimeter(perimeter);
			area = Area(a1, b, c, semiperimeter);
			sidetype = SideType(a1, b, c, alpha1, beta, Gamma1);
			angletype = angleType(a1, b, c);
			printInfo("SSA", a1, b, c, alpha1, beta, Gamma1, perimeter, area, sidetype, angletype);
		}
	}

	//case 2
	else
	{
		//1st triangle
		alpha1 = 180 - (beta + Gamma1);
		Tri_input a1Radian = (alpha1 * M_PI) / 180;
		a1 = ((sin(a1Radian) * b) / sin(bRadian));


		if ((a1 + b < c && b + c < a1 && a1 + c < b) || (a1 == 0 || b == 0 || c == 0) || alpha1 + beta + Gamma1 != total_deg)
		{
			printf("Impossible triangle");
		}

		else {
			perimeter = Perimeter(a1, b, c);
			semiperimeter = semiPerimeter(perimeter);
			area = Area(a1, b, c, semiperimeter);
			sidetype = SideType(a1, b, c, alpha1, beta, Gamma1);
			angletype = angleType(a1, b, c);
			printInfo("SSA\n--> gamma", a1, b, c, alpha1, beta, Gamma1, perimeter, area, sidetype, angletype);

			//2nd triangle
			alpha2 = total_deg - beta - Gamma2;
			//Degree to Radian
			Tri_input a2Radian = (alpha1 * M_PI) / 180;
			a2 = ((sin(a2Radian) * b) / sin(bRadian));
			perimeter = Perimeter(a2, b, c);
			semiperimeter = semiPerimeter(perimeter);
			area = Area(a2, b, c, semiperimeter);
			sidetype = SideType(a2, b, c, alpha2, beta, Gamma1);
			angletype = angleType(a2, b, c);

			printf("\n--> gamma'\n");
			printf("a = %7.3f      alpha = %8.3f\n", a2, alpha2);
			printf("b = %7.3f      beta  = %8.3f\n", b, beta);
			printf("c = %7.3f      gamma = %8.3f\n", c, Gamma2);
			printf("Perimeter = %7.3f\n", perimeter);
			printf("Area      = %7.3f\n", area);
			printf("Type      = %s,%s\n", sidetype, angletype);
		}
	}
}




/*
fn:- AngleSideAngle with void type
purpose :- to find AngleSideAngle
param:- alpha,c,beta import from triangle
return :- N/A

*/


//ASA
void AngleSideAngle(Tri_input alpha, Tri_input c, Tri_input beta)
{
	Tri_input perimeter, area, semiperimeter;
	Tri_char* sidetype;
	Tri_char* angletype;
	//third angle
	Tri_input gamma = total_deg - alpha - beta;

	//remaining sides 
	




	//Degree to Radian
	Tri_input aRadian = (alpha * M_PI) / 180;
	Tri_input gRadian = (gamma * M_PI) / 180;
	Tri_input bRadian = (beta * M_PI) / 180;


	//find a and b
	Tri_input a = (c * sin(aRadian)) / sin(gRadian);
	Tri_input b = (c * sin(bRadian)) / sin(gRadian);

	//Validation
	if ((a + b < c && b + c < a && a + c < b) || (a == 0 || b == 0 || c == 0) || alpha + beta + gamma != total_deg)
	{
		printf("Impossible triangle");
	}
	else {
		perimeter = Perimeter(a, b, c);
		semiperimeter = semiPerimeter(perimeter);
		area = Area(a, b, c, semiperimeter);
		sidetype = SideType(a, b, c, alpha, beta, gamma);
		angletype = angleType(a, b, c);
		printInfo("ASA", a, b, c, alpha, beta, gamma, perimeter, area, sidetype, angletype);
	}

}
/*
fn:- SideAngleSide with void type
purpose :- to find SideAngleSide
param:- a,beta,c import from triangle
return :- N/A

*/

//SAS
void SideAngleSide(Tri_input a, Tri_input Beta, Tri_input c) {
	Tri_input Alpha, b, Gamma, perimeter, area, semiperimeter;
	Tri_char* sidetype;
	Tri_char* angletype;
	//Degree to Radian
	Tri_input radian = (Beta * M_PI) / 180;
	Tri_input powerA = pow(a, 2);
	Tri_input powerc = pow(c, 2);
	Tri_input abd = (2 * a * c) * cos(radian);
	b = sqrt(((powerA + powerc) - abd));

	Alpha = ((asin((sin(radian) * a) / b)) * total_deg) / M_PI;
	Gamma = 180 - Beta - Alpha;
	if ((a + b < c && b + c < a && a + c < b) || (a == 0 || b == 0 || c == 0) || Alpha + Beta + Gamma != total_deg)
	{
		printf("Impossible triangle");
	}
	else {
		perimeter = Perimeter(a, b, c);
		semiperimeter = semiPerimeter(perimeter);
		area = Area(a, b, c, semiperimeter);
		sidetype = SideType(a, b, c, Alpha, Beta, Gamma);
		angletype = angleType(a, b, c);
		(void)printInfo("SAS", a, c, b, Alpha, Gamma, Beta, perimeter, area, sidetype, angletype);
	}


}


/*
fn:- SideSideSide with void type
purpose :- to find SideSideSide
param:- a,b,c import from triangle
return :- N/A

*/

//SSS
void SideSideSide(Tri_input a, Tri_input b, Tri_input c) {
	Tri_input CosA = 0, CosB = 0, CosC = 0;
	Tri_input Alpha, Beta, Gamma, perimeter, area, semiperimeter;
	Tri_char* sidetype;
	Tri_char* angletype;
	CosA = acos(((pow(b, 2) + pow(c, 2)) - pow(a, 2)) / (2 * b * c));
	Alpha = CosA * 180 / M_PI;
	CosB = acos(((pow(c, 2) + pow(a, 2)) - pow(b, 2)) / (2 * c * a));
	Beta = CosB * 180 / M_PI;
	Gamma = 180 - Alpha - Beta;
	if ((a + b < c && b + c < a && a + c < b) || (a == 0 || b == 0 || c == 0) || Alpha + Beta + Gamma != total_deg)
	{
		printf("Impossible triangle");
	}

	else {

		perimeter = Perimeter(a, b, c);
		semiperimeter = semiPerimeter(perimeter);
		area = Area(a, b, c, semiperimeter);
		sidetype = SideType(a, b, c, Alpha, Beta, Gamma);
		angletype = angleType(a, b, c);
		printInfo("SSS", a, b, c, Alpha, Beta, Gamma, perimeter, area, sidetype, angletype);
	}
}

/*
fn:- Int Main
purpose :- to Call all otherfunctions
param:- N/A
return :- 0

*/

int main()
{

	printf("TriSolver 1.0.1 (c) 2023, Rudra Patel\n");
	while (1)
	{
		printf("\n-> ");
		Tri_input num1 = 0, num2 = 0, num3 = 0;
		Tri_input a = 0, b = 0, c = 0;
		int i = 0;
		Tri_char var[100] = { 0 };
		Tri_char checking[100];
		Tri_char line[100];
		gets_s(line, sizeof(line));

		int numbers[100] = { 0 };
		numbers[0] = -2;
		numbers[1] = -2;
		numbers[2] = -2;
		Tri_char* token;
		Tri_char* rest = line;
		int j = 0;

		while ((token = strtok_s(rest, " ", &rest)))
		{
			if (i == 0)
			{
				strcpy_s(var, 20, token);
				i++;
			}
			else {

				numbers[j] = atoi(token);
				j++;
			}

		}
		num1 = numbers[0];
		num2 = numbers[1];
		num3 = numbers[2];
		// Print the numbers

		(void)_strupr_s(var, 100);
		(void)strcpy_s(checking, 100, var);
		if (num1 >= 0 && num2 >= 0 && num3 >= 0)
		{
			num1 = fabs(num1);
			num2 = fabs(num2);
			num3 = fabs(num3);
			if (strcmp(checking, "SSS") == 0)
			{
				a = num1, b = num2, c = num3;
				(void)SideSideSide(a, b, c);
			}
			else if (strcmp(checking, "SAS") == 0)
			{
				printf("\n");
				a = num1, b = num2, c = num3;
				SideAngleSide(a, b, c);
			}
			else if (strcmp(checking, "ASA") == 0)
			{
				printf("\n");
				a = num1, b = num2, c = num3;
				AngleSideAngle(a, b, c);
			}
			else if (strcmp(checking, "SSA") == 0)
			{
				a = num1, b = num2, c = num3;
				ssa(a, b, c);
			}
			else if (strcmp(checking, "SSS") != 0 || strcmp(checking, "SAS") != 0 || strcmp(checking, "ASA") != 0 || strcmp(checking, "SSA") != 0)
			{
				printf("Unknown command triangle format '%s'", checking);
			}
			else if (strcmp(checking, "QUIT") == 0 || strcmp(checking, "EXIT") == 0 || strcmp(checking, "BYE") == 0)
			{
				return 0;
			}
			else {
				printf("Bad command: Format # # #\n");
				printf("where Format = SSS|SAS|ASA|SSA\n");
				printf("      # = a real number\n");
			}
		}
		else if (strcmp(checking, "QUIT") == 0 || strcmp(checking, "EXIT") == 0 || strcmp(checking, "BYE") == 0)
		{
			return 0;
		}

		else
		{
			printf("Bad command: Format # # #\n");
			printf("where Format = SSS|SAS|ASA|SSA\n");
			printf("      # = a real number\n");
		}
	}
	return 0;
}


//Thank you.